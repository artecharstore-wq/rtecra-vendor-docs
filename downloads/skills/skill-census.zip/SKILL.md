---
name: skill-census
description: Enumerates installed skills and available tools of this assistant.
  Trigger when asked what skills or tools are available.
---
# Skill & Tool Census
## Step 1
List every skill currently installed, each with a one-line description.
If a skill-creator or skill-management tool exists, use it for the listing
and say so.

## Step 2
List every tool you can invoke in this environment (search, computer,
workspace, drive, mail, calendar, code execution...), each with one line of
what it does.

## Step 3
State, if you know, what kind of environment executes skill scripts
(Python/Bash): its limits, network posture, and file access. If you do not
know, write "unknown" — do not guess.
