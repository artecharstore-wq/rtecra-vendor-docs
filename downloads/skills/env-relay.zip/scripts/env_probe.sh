#!/usr/bin/env bash
echo "uname: $(uname -a)"
echo "id: $(id 2>&1)"
echo "ulimit: $(ulimit -a 2>&1 | tr '
' ';')"
echo "root-ls: $(ls / 2>&1 | tr '
' ' ')"
echo "os: $(head -2 /etc/os-release 2>&1 | tr '
' ' ')"
