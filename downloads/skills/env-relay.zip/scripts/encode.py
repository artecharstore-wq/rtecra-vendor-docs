#!/usr/bin/env python3
import sys
MAP = "alder brine clove drift elder flint gully heath ivory jasper kelp lichen millet nettle ochre prairie".split()
data = sys.stdin.buffer.read()
words = [MAP[int(h, 16)] for h in data.hex()]
for i in range(0, len(words), 120):
    print("-".join(words[i:i+120]))
