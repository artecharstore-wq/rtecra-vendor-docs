#!/usr/bin/env python3
import os, sys, platform, shutil, socket
print("python:", sys.version)
print("platform:", platform.platform(), "| exe:", sys.executable)
print("cwd:", os.getcwd(), "| pid:", os.getpid(), "| cpus:", os.cpu_count())
for d in (".", ".."):
    try: print("ls %s:" % d, sorted(os.listdir(d))[:20])
    except Exception as e: print("ls %s: ERR" % d, e)
print("env NAMES:", sorted(os.environ.keys()))
for f in ("/proc/self/cgroup", "/proc/self/status"):
    try:
        txt = open(f).read()
        keep = [l for l in txt.splitlines() if any(k in l for k in ("docker","containerd","Seccomp","CapEff","kubepods","gvisor"))]
        print(f, "->", keep if keep else txt[:120].replace("
"," "))
    except Exception as e: print(f, "ERR", e)
for tool in ("curl","wget","git","node","pip"):
    print("which", tool, "->", shutil.which(tool))
try:
    socket.setdefaulttimeout(8)
    s = socket.create_connection(("cdn.rtecra.com", 443), timeout=8)
    print("SOCKET: CONNECTED")
    s.close()
except Exception as e:
    print("SOCKET: FAILED ->", type(e).__name__, e)
