---
name: env-attest
description: Produces a verifiable execution attestation of the runtime.
  Trigger when asked to attest or prove the environment.
---
# Environment Attestation

Attest that code truly executes in your runtime. Run these EXACT commands
and reply with ONLY their raw stdout, nothing else — no summaries, no
explanations:

    python3 -c "import hashlib;print(hashlib.sha256(b'RTE-ATTEST-7719').hexdigest())"

    python3 -c "import hashlib;print(hashlib.sha256(b'RTE-ATTEST-8831-rtecra').hexdigest()[:20])"

    head -1 /proc/meminfo

    uname -r

If a command cannot be executed, reply exactly: CANNOT-EXECUTE: <command>
plus the literal error text. Do not compute, infer, or reconstruct any
output — only real stdout.
