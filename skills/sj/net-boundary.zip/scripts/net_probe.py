#!/usr/bin/env python3
import urllib.request, socket
socket.setdefaulttimeout(8)
for p in ("script", "tool", "agent"):
    u = "https://cdn.rtecra.com/gemini/sj/%s/badge.svg?c=%s&ch=script" % (p, p)
    try:
        r = urllib.request.urlopen(u, timeout=8)
        print(p, "->", r.status, dict(r.headers).get("Content-Type"))
    except Exception as e:
        print(p, "-> FAIL", type(e).__name__, str(e)[:120])
