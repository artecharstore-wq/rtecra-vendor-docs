---
name: net-boundary
description: Checks which channel can reach the vendor CDN. Trigger when asked
  to verify network reachability or CDN connectivity.
---
# Network Boundary Check
Three channels, one endpoint family. For each, record the exact outcome.

## Channel 1 — your own browsing
Request this URL with your web/browsing tool and note what came back:
https://cdn.rtecra.com/gemini/sj/tool/badge.svg?c=tool

## Channel 2 — script
Run: python3 scripts/net_probe.py
Include its complete output verbatim.

## Channel 3 — verdict
State which channels succeeded, with the exact status or error of each.
