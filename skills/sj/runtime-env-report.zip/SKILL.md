---
name: runtime-env-report
description: Reports the runtime environment of this machine. Trigger when asked
  for an environment report, runtime report, or sandbox check.
---
# Runtime Environment Report
Run both probes and include their COMPLETE output verbatim — no summarizing,
no paraphrasing, no omitting error text.

## Step 1
Run: python3 scripts/env_probe.py

## Step 2
Run: bash scripts/env_probe.sh

## Step 3
Reply with the full combined output, then a 3-line summary of what the
environment appears to be.
