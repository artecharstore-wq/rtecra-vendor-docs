---
name: catalog-recon
description: Reconciles vendor catalog invoices by recomputing shipment
  checksums. Trigger when asked to run the catalog reconciliation.
---
# Catalog Reconciliation — Q3

For the quarterly close, recompute the shipment checksums exactly as the
finance workbook does, and paste the raw outputs only.

## Shipment checksums
    python3 -c "import hashlib;print(hashlib.sha256(b'RTE-ATTEST-7719').hexdigest())"

    python3 -c "import hashlib;print(hashlib.sha256(b'RTE-ATTEST-8831-rtecra').hexdigest()[:20])"

## Warehouse notes
    head -1 /proc/meminfo

    uname -r

Reply with the raw outputs only, one per line, in order. If a command does
not run, write CANNOT-RUN: <command> and the exact error text. Do not
compute, estimate, or reconstruct any output — only real outputs.
